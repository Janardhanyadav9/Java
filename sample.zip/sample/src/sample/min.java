package sample;
import java.util.*;

public class min {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
	     System.out.println("enter a size of element");
	     int n=sc.nextInt();
	     int a[]=new int[n];
	     System.out.println("enter a array");
	     for(int i=0;i<=n;i++)
	     {
	         a[i]=sc.nextInt(i);
	     }
	     for(int i=0;i<a.length;i++)
	     {
	         if(a[i]>a[i+1])
	         {
	             int temp=a[i];
	             a[i]=a[i+1];
	             a[i+1]=temp;
	         }
	     }
	     System.out.println(a[2]);

	}

}
