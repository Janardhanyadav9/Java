package sample;

import java.util.Arrays;

public class remove {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {2,3,4,5,6};
		int b[]=new int[a.length-1];
		for(int i=0,k=0;i<a.length;i++)
		{
			if(i==3)
			{
				continue;
			}
			b[k++]=a[i];
		}
		System.out.println(Arrays.toString(b));
			
		

}
}