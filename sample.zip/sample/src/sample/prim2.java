package sample;

public class prim2 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int c=1;
		int n=1;
		while(c<=500)
		{
			int p=0;
			for(int i=1;i<=n;i++)
			{
				if(n%i==0)
				{
				p++;	
				
			}
			}
			if(p==2)
			{
				sum=sum+n;
				c++;
			}
			n++;
			}
		
				System.out.println(sum);
			
		

	}

}
