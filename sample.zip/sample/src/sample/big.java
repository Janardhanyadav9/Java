package sample;

public class big {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=23697;
		int fixedd=n%10;
		while(n!=0)
		{
			int r=n%10;
			if(r>fixedd)
			{
				fixedd=r;
			}
			n=n/10;
		}
		System.out.println(fixedd);

	}

}
