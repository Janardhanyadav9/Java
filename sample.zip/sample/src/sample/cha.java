package sample;

public class cha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		char ch;
		for(ch='a';ch<='z';ch++)
		{
			System.out.println(ch);
		}

	}

}
