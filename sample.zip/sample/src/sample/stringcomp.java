package sample;

public class stringcomp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String str="jana";
		//String str1="jana";
		String str=new String("jana");
		String str1=new String("jana");
		
		if(str.equals(str1))
		{
			System.out.println("equal");
		}
		else
		{
			System.out.println("not equal");
		}

	}

}
