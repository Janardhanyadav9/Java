package sample;

import java.util.Scanner;

public class average {
	void f(int a,int b,int c)
	{
		System.out.println((a+b+c)/3);
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		average obj=new average();
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		int c=sc.nextInt();
		obj.f(a,b,c);

	}

}
