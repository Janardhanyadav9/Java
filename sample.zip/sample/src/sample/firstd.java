package sample;

public class firstd {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=123;
		int f=0;
		int l=0;
		l=n%10;
		System.out.println(l);
		while(n!=0)
		{
			f=n%10;
		n=n/10;
		}
		System.out.println(f);

	}

}
