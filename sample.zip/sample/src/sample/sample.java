package sample;

public class sample {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=36;
		if(a>0)
		{
			System.out.println("positiv number");
		}
		else if(a<0)
		{
			System.out.println("negative number");
		}
		else
		{
			System.out.println("zero");
		}


	}

}
