package sample;

public class check {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10;
		if(a%2==0)
		{
			System.out.println("even");
		}
		else
		{
			System.out.println("odd");
		}

	}

}
