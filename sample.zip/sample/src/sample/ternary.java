package sample;

public class ternary {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=200;
		int b=300;
		int c=202;
		int res=((a>=b && a>=c)? a:(b>=c)?b:c);
		System.out.println(res);

	}

}
