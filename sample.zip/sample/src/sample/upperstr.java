package sample;

public class upperstr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String str="janardhan";
		//String s=str.toUpperCase();
		char str='j';
		char a=Character.toUpperCase(str);
		System.out.println(a);

	}

}
