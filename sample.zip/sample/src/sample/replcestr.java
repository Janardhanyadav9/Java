package sample;
import java.util.*;
public class replcestr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s=sc.nextLine();
		String str="";
		for(int i=0;i<s.length();i++)
		{
			if(s.charAt(i)==' ')
			{
				char a=s.charAt(i-1);
						str=str+" "+a;
						i++;
			}
			else
			{
				str=str+s.charAt(i);
			}
		
			System.out.println(str);
		}

	}

}
