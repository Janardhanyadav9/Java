package sample;

public class lengthstring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
		String str="janardhan";
		 str= str +'@';
		 for(int i=0;str.charAt(i)!='@';i++)
		 {
			c++; 
		 }
		 System.out.println(c);
				

	}

}
