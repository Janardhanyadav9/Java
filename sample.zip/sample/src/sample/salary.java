package sample;
import java.util.Scanner;

public class salary {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		int YourSalary=sc.nextInt();
		System.out.println("your salary"+" "+ YourSalary);

	}

}
