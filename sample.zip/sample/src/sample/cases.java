package sample;

import java.util.Scanner;

public class cases {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a character");
		char s=sc.next().charAt(0);
		if(s>='a' &&  s<='z')
		{
			System.out.println("Lower case");
		}
		else if(s>='A' && s<='Z')
		{
			System.out.println("Upper case");
		}
		else
		{
			System.out.println("digit");
		}
		
	}

}
