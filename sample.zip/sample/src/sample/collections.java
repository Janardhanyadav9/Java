package sample;
import java.util.*;

public class collections {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []a={1,10,10,10,4};
	    ArrayList<Integer>arr=new ArrayList();
	    for(int i=0;i<a.length;i++)
	    {
	     arr.add(a[i]);  
	    }
	    int x=Collections.max(arr);
	    System.out.println(x);
	
	}

}
