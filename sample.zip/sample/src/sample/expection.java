package sample;

public class expection {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		int a=100;
		int b=0;
		int c=a/b;
		int arr[]= {1,2,3,4,5};
		System.out.println("done");
		}
		catch(ArithmeticException e)
		{
		System.out.println("got");
		System.out.println(e);
		}
		
		
	}

}
