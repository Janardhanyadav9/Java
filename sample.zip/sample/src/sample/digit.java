package sample;

public class digit {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=12345;
		int c=0;
		while(n>0)
		{
			n=n/10;
			c++;
		}
		System.out.println(c);

	}

}
