package sample;


public class array1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a[]= {2,4,45,23,34,456,56};
		int max=a[3];
		int min=a[5];
		for(int j=0;j<a.length;j++)
		{
		if	(a[j]>max)
		{
			max=a[j];
		}
		if(a[j]<min)
		{
			min=a[j];
		}
		}
		System.out.println(max);
		System.out.println(min);
	}
	

}
