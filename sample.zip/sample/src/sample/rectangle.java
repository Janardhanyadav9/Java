package sample;
import java.util.Scanner;
public class rectangle {
	int react(int a,int b) {
		return a*b;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		rectangle obj=new rectangle();
Scanner sc=new Scanner(System.in);
int a=sc.nextInt();
int b=sc.nextInt();
System.out.println(obj.react(a,b));
	}

}
