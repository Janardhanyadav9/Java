package sample;

public class chari {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan@";
		for(int i=0;i<str.length();i++)
		{
			char ch=str.charAt(i);
			if(ch=='a'|| ch=='e'||ch=='i'||ch=='o'||ch=='u')
			{
				System.out.println(Character.toUpperCase(ch));
			}
			else if(ch>=65 && ch<=90  || ch>=97 && ch<=122)
			{
				System.out.println(Character.toUpperCase(ch));
			}
			else
			{
				System.out.println(ch);
			}
		}

	}

}
