package sample;

public class oper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=20;
		int b=10;
		int res=(a>=b)?a:b;
		System.out.println(res);

	}

}
