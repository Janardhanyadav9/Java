package sample;

public class series1 {

	static int fact(int a)
	{
		int v=1;
		for(int j=0;j<=a;j++)
		{
			v=v*a;
		}
		return v;
	}
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=2;
		float sum=0;
		for(int i=0;i<=5;i++)
		{
			System.out.println("1"+"+"+(Math.pow(x,i))/fact(i));
		}
		

	}

}
