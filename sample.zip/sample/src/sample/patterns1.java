package sample;
import java.util.*;
public class patterns1 {
	static int fact(int i) {
		if(i==0)
		{
			return 1;
		}
		else
		{
			return i*fact(i-1);
		}
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int n=sc.nextInt();
		for(int i=0;i<n;i++)
		{
			if(i==1)
			{
				continue;
			}
			else
			{
				for(int j=0;j<n-1;j++)
				{
					System.out.println(" ");
				}
				for(int k=0;k<=i;k++)
				{
					System.out.println(" "+fact(i)/(fact(i-k)*fact(k)));
				}
			}
		}

	}

}
