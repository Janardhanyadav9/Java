package sample;

public class perfe {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
		int sum=0;
		int n=1;int j=0;
		while(c<=500)
		{
		sum=0;	
		for(int i=1;i<n;i++)
		{
			if(n%i==0)
			{
				sum=sum+i;
			}
		
		
			
		}
		if(sum==n)
		{
			c++;
			j=j+n;
			System.out.println(j);
			System.out.println(sum);
		}
		n++;
		}
		
	
	}

}
