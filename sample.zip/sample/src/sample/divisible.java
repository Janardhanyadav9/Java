package sample;

import java.util.Scanner;

public class divisible {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		/*int b=sc.nextInt();*/
		if((a%5==0) && (a%3==0))
		{
			System.out.println("divisible by both");
		}
		else
		{
			System.out.println("not disivible");
		}
	}
		}


