package sample;
import java.util.*;

public class names {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
		int d=0;
		String str="this is really good project";
		for(int i=0;i<str.length();i++)
		{
			if(str.charAt(i)=='a' || str.charAt(i)=='e'|| str.charAt(i)=='i' ||str.charAt(i)=='o' ||str.charAt(i)=='u')
			{
				c++;
				
			}
			else if(str.charAt(i)>='a' && str.charAt(i)<='z')
			{
				d++;
			}
		}
			System.out.println(c);
			System.out.println(d);
			
				
			
		
	}

}
