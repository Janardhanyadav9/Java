package sample;

public class captalize {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan yadav";
        String s="";
        str=" "+str;
        for(int i=0;i<str.length();)
        {
            char ch=str.charAt(i);
            
            if(ch==' ')
            {
                s = s+' '+Character.toUpperCase(str.charAt(i+1));
                i=i+2;
            }
            else
            {
            s=s+str.charAt(i);
            i++;
            }
        }
        System.out.println(s);

	}

}
