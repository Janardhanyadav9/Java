package sample;

public class perfect {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
int j=1;
		for(int i=1;i<=10;i++)
		{
			int sum=0;
			for(j=1;j<i;j++)
			{
				if(i%j==0)
				{
					sum=sum+j;
				}
			}
			if(sum==i)
			{
				System.out.println(i);
			}
		}

	}

}
