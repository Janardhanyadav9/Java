package sample;

public class numberword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
        int w=1;
        String str ="janardhan yadav bura@";
        
        for(int i=0;i<=str.length()-1;i++)
        {
            char d=str.charAt(i);
        
            char ch=' ';
        
        if(ch!=d)
        {
            c++;
        }
        else if(ch==d)
        {
            w++;
        }
        else
        {
        System.out.println("null");    
        }
        }   
    System.out.println(c);

	}

}
