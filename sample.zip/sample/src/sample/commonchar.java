package sample;
import java.util.*;
public class commonchar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string1");
		String a=sc.nextLine();
		System.out.println("enter a string2");
		String b=sc.nextLine();
		String s="";
		for(int i=0;i<a.length();i++)
		{
			for(int j=0;j<b.length();j++)
			{
				if(a.charAt(i)==b.charAt(j))
				{
					c++;
					s=s+a.charAt(j);
				}
			}
		}
			
		System.out.print(s);
					
				
	}

}
