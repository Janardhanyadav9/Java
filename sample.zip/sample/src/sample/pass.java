package sample;

import java.util.Scanner;

public class pass {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int n=35;
		if(a>n)
		{
			System.out.println(" pass");
		}
		else 
		{
			System.out.println("fail");
		}

	}

}
