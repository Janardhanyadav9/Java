package sample;
import java.util.*;
class janaException extends Exception
{
	janaException(String s)
	{
		super(s);
	}
}

public class excep {
	static double balance=20000;
	static void balance()throws janaException
	{
		System.out.println("balance:"+balance);
	}
	static void withdraw(double withdraw )throws janaException {
		if(withdraw<balance)
		{
			balance=balance-withdraw;
			System.out.println("withdraw is:"+withdraw+" ,"+"balance is:"+balance);
			
		}
		else
		{
			throw new janaException("insufficient");
		}
	}
	static void deposite(double deposite )throws janaException {
		if(deposite>500)
		{
			balance=balance+deposite;
			System.out.println("deposite is:"+deposite+" ,"+"balance is:"+balance);
			
		}else
		{
			throw new janaException("insufficient");
		}
	}

	public static void main(String[] args) throws janaException {
		// TODO Auto-generated method stub
		int n=3;

		Scanner sc=new Scanner(System.in);
		String username=sc.next();
		String password=sc.next();
		String name="jana";
		String key="yadav";
		while(n>0)
		{
		if(username.equals(name) && password.equals(key))
		{
			System.out.println("1.balance,2.withdraw,3.deposite,4.exit");
			System.out.println("enter your content");
			int a=sc.nextInt();
			while(a!=4)
			{
			switch(a)
			{
				case 1:
					System.out.println("balance is :"+balance);
					balance();
					break;
				case 2:
					System.out.println("withdraw amount");
					int withdraw=sc.nextInt();
					try
					{
						withdraw(withdraw );
					}
					catch(janaException e)
					{
					System.out.println(e);	
					}
					break;
				case 3:
					System.out.println("deposite amount");
					int deposite=sc.nextInt();
					try
					{
					  deposite(deposite);
					System.out.println("deposite is:"+deposite+" ,"+"balance is:"+balance);
					}
					catch(janaException e)
					{
						System.out.println(e);
					}
				
			}
			a=sc.nextInt();
			}
		System.out.println("succesfull");
		break;
		}
		else 
		{
			if(username!=name && password!=key)
		{
				System.out.println("enter correct value");
				username=sc.next();
				password=sc.next();
				n--;
		}

	}

}
	}
}
