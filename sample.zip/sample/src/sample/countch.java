package sample;

public class countch {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;
		String str="janardhan";
		String s=str+'@';
		for(int i=0;s.charAt(i)!='@';i++)
		{
			c++;
		}
		System.out.println(c);


	}

}
