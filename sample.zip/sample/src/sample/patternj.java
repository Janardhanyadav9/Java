package sample;
import java.util.*;

public class patternj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
      int i,j,n=6;
		for( i=0;i<=n;i++)
		{
		for( j=2*(n-i);j>=0;j--)
			{
				System.out.print(" ");
			}
		for(j=0;j<=i;j++)
			{
		System.out.print("* ");
		}
		System.out.println();
		}

	}

}
