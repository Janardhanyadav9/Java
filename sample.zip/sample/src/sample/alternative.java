package sample;
import java.util.Scanner;

public class alternative {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		for(int i=0;i<=a;i+=4)
		{
			if(i%2==0)
			{
				System.out.println(i+"even");
			}
			
		}

	}

}
