package sample;

public class student {
	void d(int roll,String name) {
		System.out.println(roll);
		System.out.println(name);
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		student obj=new student();
		obj.d(3,"jana");
		

	}

}
