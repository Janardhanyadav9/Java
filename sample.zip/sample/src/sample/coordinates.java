package sample;

public class coordinates {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int x=1;
		int y=0;
		if(x>0 && y>0)
		{
			System.out.println("1 quardant");
		}
		else if(x<0 && y>0)
		{
			System.out.println("2 quardant");
		}
		else if(x<0 && y<0)
		{
			System.out.println("3 quardant");
		}
		else if(x>0 && y<0)
		{
			System.out.println("4 quardant");
		}
		else if(x==0 && y==0)
		{
			System.out.println("origin");
		}
		else if(y==0 && x!=0)
				{
			System.out.println("x -axis");
			}
		else
		{
			System.out.println("y-axis");
		}

	}

}
