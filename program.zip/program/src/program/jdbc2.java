package program;
import java.sql.*;
import java.util.Scanner;
public class jdbc2 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner s=new Scanner(System.in);
		Class.forName("com.mysql.cj.jdbc.Driver");
		int n=s.nextInt();
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		for(int i=0;i<n;i++)
		{
			String name=s.next();
			int ph=s.nextInt();
			String ad=s.next();
			//int ph=s.nextInt();
			int pr=s.nextInt();
			int id=s.nextInt();
		PreparedStatement s1=con.prepareStatement("insert into student values(?,?,?,?,?)");
		//PreparedStatement s1=con.prepareStatement("update student set age=?");
		s1.setInt(1,id);
		s1.setString(2,name);
		s1.setString(3,ad);
		s1.setInt(4,ph);
		s1.setInt(5,pr);
		s1.executeUpdate();
		}
		System.out.println("updated record");
		con.close();

	}

}
