package program;
import java.sql.Connection;
import java.util.Scanner;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class emp {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter id");
		int id=sc.nextInt();
		System.out.println("enter pin");
		int pin=sc.nextInt();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		PreparedStatement ps=con.prepareStatement("select roles from office where id='"+id+"' and  pin='"+pin+"'");
		ResultSet rs=ps.executeQuery();
		
		while(rs.next())
		{
			if(rs.getString("roles").equals("hr"))
			{
				PreparedStatement ps1=con.prepareStatement("select * from emp");
				ResultSet rs1=ps1.executeQuery();
				while(rs1.next())
				{
					System.out.println("enter choice 1.delete 2.insert 3.update 4.select 5.exit");
				
					int a=sc.nextInt();
					while(a<=5) {
					//System.out.println(rs1.getInt("id")+" "+rs1.getString("address"));
					//System.out.println("1.delete 2.insert 3.update 4.select");
					
					
					switch(a)
					{
					case 1:
						System.out.println("enter a id to delete from employee");
						int id1=sc.nextInt();
						PreparedStatement ps3=con.prepareStatement("delete from emp where id=?");
						ps3.setInt(1,id1);
						ps3.executeUpdate();
						PreparedStatement ps7=con.prepareStatement("delete from office where id=?");
						ps7.setInt(1,id1);
						ps7.executeUpdate();
						
					
					break;
				 case 2:
					//int id2=sc.nextInt();
					 System.out.println("enter a role to insert  from employee");
					String role=sc.next();
					System.out.println("enter a id to insert  from employee");
					int id2=sc.nextInt();
					System.out.println("enter a address to insert  from employee");
					String adress=sc.next();
					PreparedStatement ps4=con.prepareStatement("insert into emp(id,roles,address) values (?,?,?)");
					ps4.setInt(1,id2);
					ps4.setString(2,role);
					ps4.setString(3,adress);
					ps4.executeUpdate();
					PreparedStatement ps5=con.prepareStatement("insert into office(id,pin,roles) values (?,?,?)");
					ps5.setInt(1,id2);
					ps5.setString(3,role);
					ps5.setInt(2,7);
					
					break;
				 case 3:
						System.out.println("enter a id to update  from employee");
						//int id2=sc.nextInt();
						int id3=sc.nextInt();
						System.out.println("enter a role to insert  from employee");
						String role1=sc.next();
						//String adress=sc.next();
						PreparedStatement ps6=con.prepareStatement("update emp set id=? where roles=?");
						ps6.setInt(1,id3);
						ps6.setString(2,role1);
						//ps4.setString(3,adress);
						ps6.executeUpdate();
						PreparedStatement ps8=con.prepareStatement("update office set id=? where roles=?");
						ps8.setInt(1,id3);
						ps8.setString(2,role1);
						//ps7.setInt(2,7);
						ps8.executeUpdate();
						break;
				case 4:
							System.out.println("enter a id to select  from employee");
							//int id2=sc.nextInt();
							//String role1=sc.next();
							int id5=sc.nextInt();
							//String adress=sc.next();
							PreparedStatement ps9=con.prepareStatement("select * from emp where id=?");
							ps9.setInt(1,id5);
							//ps5.setString(2,role1);
							//ps4.setString(3,adress);
							ResultSet rs2=ps9.executeQuery();
							while(rs2.next())
							{
								System.out.println(rs2.getInt("id")+" "+rs2.getString("roles")+" "+rs2.getString("address"));
							}
							break;
				case 5:
					System.out.println("successfull");
					System.exit(0);
					
					}
				    System.out.println("enter your choice 1.delete 2.insert 3.update 4.select 5.exit");
					a=sc.nextInt();
					}
					}
				System.out.println("successfull");
			}
			if(rs.getString("roles").equals("tr"))
			{
				PreparedStatement ps1=con.prepareStatement("select * from emp where roles='tr' or roles='em'");
				ResultSet rs1=ps1.executeQuery();
				while(rs1.next())
				{

					System.out.println("enter choice 1.delete 2.insert 3.update 4.select 5.exit");
				
					int a=sc.nextInt();
					while(a<=5) {
					//System.out.println(rs1.getInt("id")+" "+rs1.getString("address"));
					switch(a)
					{
					case 1:
						System.out.println("enter a id to delete from employee");
						int id1=sc.nextInt();
						PreparedStatement ps3=con.prepareStatement("delete from emp where id=?");
						ps3.setInt(1,id1);
						ps3.executeUpdate();
						PreparedStatement ps2=con.prepareStatement("delete from office where id=?");
						ps2.setInt(1,id1);
						ps2.executeUpdate();	
					break;
					case 2:
						System.out.println("enter a role to insert  from employee");
						//int id2=sc.nextInt();
						String role=sc.next();
						System.out.println("enter a id to insert  from employee");
						int id2=sc.nextInt();
						System.out.println("enter a address to insert  from employee");
						String adress=sc.next();
						PreparedStatement ps4=con.prepareStatement("insert into emp(id,roles,address) values (?,?,?)");
						ps4.setInt(1,id2);
						ps4.setString(2,role);
						ps4.setString(3,adress);
						ps4.executeUpdate();
						PreparedStatement ps5=con.prepareStatement("insert into office(id,pin,roles) values (?,?,?)");
						ps5.setInt(1,id2);
						ps5.setString(3,role);
						ps5.setInt(2,7);
						ps5.executeUpdate();
						break;
					case 3:
						System.out.println("enter a role to update  from employee");
						//int id2=sc.nextInt();
						String role1=sc.next();
						System.out.println("enter a id to insert  from employee");
						int id3=sc.nextInt();
						//String adress=sc.next();
						PreparedStatement ps7=con.prepareStatement("update emp set id=? where roles=?");
						ps7.setInt(1,id3);
						ps7.setString(2,role1);
						//ps4.setString(3,adress);
						ps7.executeUpdate();
						PreparedStatement ps9=con.prepareStatement("update office set id=? where roles=?");
						ps9.setInt(1,id3);
						ps9.setString(2,role1);
						//ps4.setString(3,adress);
						ps9.executeUpdate();
						break;
					case 4:
						System.out.println("enter a id to select  from employee");
						//int id2=sc.nextInt();
						//String role1=sc.next();
						int id5=sc.nextInt();
						//String adress=sc.next();
						PreparedStatement p=con.prepareStatement("select * from emp where id=?");
						p.setInt(1,id5);
						//ps5.setString(2,role1);
						//ps4.setString(3,adress);
						ResultSet rs2=p.executeQuery();
						while(rs2.next())
						{
							System.out.println(rs2.getInt("id")+" "+rs2.getString("roles")+" "+rs2.getString("address"));
						}
						break;
					case 5:
						System.out.println("successfull");
						System.exit(0);
					}
					 System.out.println("enter your choice 1.delete 2.insert 3.update 4.select 5.exit");
					a=sc.nextInt();
				}
					}
				System.out.println("successfull");
			}
			if(rs.getString("roles").equals("emp"))
			{
				PreparedStatement ps1=con.prepareStatement("select * from emp where roles='em' ");
				ResultSet rs1=ps1.executeQuery();
				while(rs1.next())
				{
					System.out.println("enter choice 1.delete 2.insert 3.update 4.select 5.exit");
					
					int a=sc.nextInt();
					while(a<=5) {
					//System.out.println(rs1.getInt("id")+" "+rs1.getString("address"));
					switch(a)
					{
					case 1:
						System.out.println("enter a id to delete from employee");
						int id1=sc.nextInt();
						System.out.println("enter a role to insert  from employee");
						String roles=sc.next();
						PreparedStatement ps3=con.prepareStatement("update emp set roles=? where id=? ");
						ps3.setString(1,roles);
						ps3.setInt(2,id1);
						ps3.executeUpdate();	
						PreparedStatement ps4=con.prepareStatement("update office set roles=? where id=? ");
						ps4.setString(1,roles);
						ps4.setInt(2,id1);
						ps4.executeUpdate();
					break;
					case 2:
						System.out.println("enter a role to insert  from employee");
						//int id2=sc.nextInt();
						String role=sc.next();
						System.out.println("enter a id to insert  from employee");
						int id2=sc.nextInt();
						System.out.println("enter a address to insert  from employee");
						String adress=sc.next();
						PreparedStatement ps5=con.prepareStatement("insert into emp(id,roles,address) values (?,?,?)");
						ps5.setInt(1,id2);
						ps5.setString(2,role);
						ps5.setString(3,adress);
						ps5.executeUpdate();
						PreparedStatement ps6=con.prepareStatement("insert into office(id,pin,roles) values (?,?,?)");
						ps6.setInt(1,id2);
						ps6.setString(3,role);
						ps6.setInt(2,8);
						ps6.executeUpdate();
						break;
					case 3:
						System.out.println("enter a role to update  from employee");
						//int id2=sc.nextInt();
						String role1=sc.next();
						System.out.println("enter a id to insert  from employee");
						int id3=sc.nextInt();
						PreparedStatement ps7=con.prepareStatement("update emp set id=? where roles=?");
						ps7.setInt(1,id3);
						ps7.setString(2,role1);
						//ps4.setString(3,adress);
						ps7.executeUpdate();
						PreparedStatement ps9=con.prepareStatement("update office set id=? where roles=?");
						ps9.setInt(1,id3);
						ps9.setString(2,role1);
						//ps4.setString(3,adress);
						ps9.executeUpdate();
						break;
					case 4:
						System.out.println("enter a id to select  from employee");
						//int id2=sc.nextInt();
						//String role1=sc.next();
						int id5=sc.nextInt();
						//String adress=sc.next();
						PreparedStatement ps2=con.prepareStatement("select * from emp where id=?");
						ps2.setInt(1,id);
						//ps5.setString(2,role1);
						//ps4.setString(3,adress);
						ResultSet rs2=ps2.executeQuery();
						while(rs2.next())
						{
							System.out.println(rs2.getInt("id")+" "+rs2.getString("roles")+" "+rs2.getString("address"));
						}
						break;
					case 5:
						System.out.println("successfull");
						System.exit(0);
					}
					System.out.println("enter your choice 1.delete 2.insert 3.update 4.select 5.exit");
					a=sc.nextInt();
				}
					}
				System.out.println("successfull");
			}
	
}
	}
}

