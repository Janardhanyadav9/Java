package program;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class empl {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		PreparedStatement ps=con.prepareStatement("update student set phone=?,price=?,age=? where id=? and name=? and address=?");
	ps.setInt(1,1234);
		ps.setString(2,"500");
	ps.setInt(3,25);
	ps.setInt(4,4);
	ps.setString(5,"ramu");
		ps.setString(6,"hyd");
		int i=ps.executeUpdate();
System.out.println(i);
		
			

	}

}
