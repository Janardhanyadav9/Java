package program;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;

public class res {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		//PreparedStatement ps=con.prepareStatement("select id,name,address from student where price=70");
		PreparedStatement ps=con.prepareStatement("select * from student",ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
		//String s="r";
		//String a="u";
		//String ob=("select * from student where name like '%"+s+"'");
		//String ob=("select * from student where name like '"+s+"%' and name like '%"+a+"'");
		//PreparedStatement ps= con.prepareStatement(ob);
	//	PreparedStatement ps= con.prepareStatement("select * from student");
		ResultSet rs=ps.executeQuery();
		//rs.first();
	//rs.afterLast();
	//	rs.beforeFirst();
//		ResultSetMetaData rm=rs.getMetaData();
//		System.out.println(rm.getColumnTypeName(2));
//		int i=rm.getColumnCount();
//		for(int j=1;j<=i;j++)
//		{
//			System.out.print(rm.getColumnTypeName(j)+" ");
//		}
		
rs.absolute(5);
rs.relative(3);
//		System.out.println(" ");
		
	while(rs.previous())
//	{
	System.out.println(rs.getInt("id")+" "+rs.getString("name")+" "+rs.getString("address"));
//		}

	}

}
