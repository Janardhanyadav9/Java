package program;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

import sample.janaException;

//import sample.janaException;
class janaException extends Exception
{
	janaException(String s)
	{
		super(s);
	}
}

public class done {
	static void withdraw(float withdraw,float balance,Connection con,int account )throws janaException, SQLException {
		if(withdraw<balance)
		{
			balance=balance-withdraw;
			PreparedStatement ps=con.prepareStatement("update bank set balance=? where accountnumber=?");
			ps.setFloat(1, balance);
			ps.setFloat(2,account);
			ps.executeUpdate();
			
			System.out.println("withdraw is:"+withdraw+" ,"+"balance is:"+balance);
			
		}
		else
		{
			throw new janaException("insufficient");
		}
	}
	static void deposite(float deposite,float balance,Connection con,int account )throws janaException, Exception {
		if(deposite>500)
		{
			balance=balance+deposite;
			PreparedStatement ps=con.prepareStatement("update bank set balance=? where accountnumber=?");
			ps.setFloat(1, balance);
			ps.setFloat(2,account);
			ps.executeUpdate();
			System.out.println("deposite is:"+deposite+" ,"+"balance is:"+balance);
			
		}
		else
		{
			throw new janaException("insufficient");
		}
	}
	static void transfer(float amount,int otheraccount,int account,Connection con,float balance)throws janaException ,Exception{
		balance=balance-amount;
		
		//otherbalance+=transfer;
		PreparedStatement ps=con.prepareStatement("select * from bank where accountnumber=?");
		ps.setInt(1,otheraccount);
	    ResultSet rs=ps.executeQuery();
	    rs.next();
	    int otherbalance=rs.getInt(4);
	    otherbalance+=amount;
	    PreparedStatement ps1=con.prepareStatement("update bank set balance=? where accountnumber=?");
	    ps1.setFloat(1, balance);
	    ps1.setInt(2, account);
	    ps1.executeUpdate();
	    PreparedStatement ps2=con.prepareStatement("update bank set balance=? where accountnumber=?");
	    ps2.setFloat(1, otherbalance);
	    ps2.setInt(2, otheraccount);
	    ps2.executeUpdate();
	    
	    
		System.out.println("otherbalance is:"+otherbalance+" ,"+"balance is:"+balance);
		
	}

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		for(int i=0;i<3;i++)
		{
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your account number");
		int account=sc.nextInt();
		System.out.println("enter your password");
		String pin=sc.next();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		String str="select * from bank";
		PreparedStatement ps=con.prepareStatement(str);
		//ps.setInt(1, account);
		
		ResultSet rs=ps.executeQuery();
		while(rs.next())
		{
			
			
		if(rs.getInt(1)==(account) && rs.getString(3).equals(pin))	
		{
			System.out.println("1.Balance 2.withdraw 3.deposite 4.transfer 5.exit");
			System.out.println("enter your content");
			int a=sc.nextInt();
			while(a<=5)
			{
			switch(a)
			{
			case 1:
				PreparedStatement ps2=con.prepareStatement("select balance from  bank where accountnumber=?");
				ps2.setInt(1,account);
				ResultSet rs1=ps2.executeQuery();
				while(rs1.next())
				{
				System.out.println(rs1.getInt(1));
				}
				break;
			case 2:
				PreparedStatement ps1=con.prepareStatement("select * from bank");
				ResultSet rs9=ps1.executeQuery();
				System.out.println("enter the withdraw ammount");
				float withdraw=sc.nextFloat();
				rs9.next();
				float balance=rs9.getFloat(4);
				try
				{
					withdraw(withdraw,balance,con,account);
				}
				catch(janaException e)
				{
				System.out.println(e);	
				}
				break;
			case 3:
				PreparedStatement ps3=con.prepareStatement("select * from bank");
				ResultSet rs8=ps3.executeQuery();
				System.out.println("deposite amount");
				float deposite=sc.nextFloat();
				rs8.next();
				 balance=rs8.getFloat(4);
				try
				{
				  deposite(deposite,balance,con,account);
				}
				catch(janaException e)
				{
					System.out.println(e);
				}
				break;
			case 4:
				PreparedStatement ps4=con.prepareStatement("select * from bank");
				ResultSet rs7=ps4.executeQuery();
				System.out.println("transfer amount");
				float amount=sc.nextFloat();
				rs7.next();
				balance=rs7.getFloat(4);
				System.out.println("enter other account number");
				int otheraccount=sc.nextInt();
				try
				{
					transfer(amount,otheraccount,account,con,balance);
				}
				catch(janaException e)
				{
					System.out.println(e);
				}
				break;
			case 5:
				System.out.println("successfull");
				System.exit(0);
				
			}
			System.out.println("1.Balance 2.withdraw 3.deposite 4.transfer 5.exit");
			a=sc.nextInt();
			}
		}
		else
		{
			System.out.println("invalid");

			break;
			}
		}
		}	
	}

}

