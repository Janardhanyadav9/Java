 package program;
import java.sql.*;

public class jc1 {


	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		//PreparedStatement s1=con.prepareStatement("alter table student add age int");
	//	PreparedStatement s1=con.prepareStatement("update student set age=?");
		//PreparedStatement s1=con.prepareStatement("delete from student where id=?");
		s1.setInt(1, 75);
		s1.executeUpdate();
		con.close();
		
		

	}

}
