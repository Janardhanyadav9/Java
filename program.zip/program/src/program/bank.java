package program;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.*;
import java.util.Scanner;

public class bank {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter your account number");
		int account=sc.nextInt();
		System.out.println("enter your password");
		String pin=sc.next();
		Class.forName("com.mysql.cj.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://127.0.0.1:3306/student data","root","M1racle@123");
		String str="select * from bank where accountnumber=?";
		PreparedStatement ps=con.prepareStatement(str,ResultSet.TYPE_SCROLL_INSENSITIVE,ResultSet.CONCUR_UPDATABLE);
		ps.setInt(1, account);
		//ps.setString(2, pin);
		ResultSet rs=ps.executeQuery();
		rs.last();
		int f=rs.getRow();
		if(f>0)
		{
			rs.previous();
		while(rs.next())
		{
		if(rs.getInt(1)==(account) && rs.getString(3).equals(pin))	
		{
			System.out.println("valid");
		}
		else
		{
			System.out.println("nvalid");
		}
		}
		}
		else
		{
			System.out.println("invlid");
		}

	}

}
