/**
 * 
 */
/**
 * @author miracle
 *
 */
module program {
	requires java.sql;
}