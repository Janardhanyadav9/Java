package demo;
import java.util.*;

public class arrlist {

	public static void main(String[] args) {
		// TODO Auto-generated method stub  
	            
	               LinkedList<String> ll=new LinkedList<String>();  
	               ll.add("Ravi");  
	               ll.add("Vijay");  
	               ll.add("Ajay");  
	               ll.add("Anuj");  
	               ll.add("Gaurav");  
	               ll.add("Harsh");  
	               ll.add("Virat");  
	               ll.add("Gaurav");  
	               ll.add("Harsh");  
	               ll.add("Amit");  
	               System.out.println("Initial list of elements: "+ll);  
	              
	                  ll.remove("Vijay");  
	                  System.out.println(ll);    
	                  ll.remove(0);  
	                  System.out.println(ll);   
	                  LinkedList<String> ll2=new LinkedList<String>();  
	                  ll2.add("Ravi");  
	                  ll2.add("Hanumat");  
	          
	                  ll.addAll(ll2);  
	                  System.out.println("Updated list : "+ll);   
	              
	                  ll.removeAll(ll2);  
	                  System.out.println(ll);   
	            
	                  ll.removeFirst();  
	                  System.out.println(ll);  
	                
	                  ll.removeLast();  
	                  System.out.println(ll);  
	  
	                  ll.removeFirstOccurrence("Gaurav");  
	                  System.out.println(ll);  
  
	                  ll.removeLastOccurrence("Harsh");  
	                  System.out.println(ll);  
	      
       
	                  ll.clear();  
	                  System.out.println(ll);   
	           }  
	      }                  



	


