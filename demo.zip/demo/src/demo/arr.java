package demo;
import java.util.*;

public class arr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>h=new ArrayList<Integer>();
		h.add(1);
		h.add(2);
		h.add(3);
		for(int i=0;i<=h.size()-1;i++)
		{
			System.out.println(h.get(i));
		}

	}

}
