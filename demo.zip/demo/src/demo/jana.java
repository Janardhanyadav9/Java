package demo;
import java.util.*;
public class jana
{
    int id;
    String name;
public jana(int id,String name)
{
        this.id=id;
        this.name=name;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 TreeMap<Integer,jana>obj=new TreeMap<Integer,jana>();
		 jana b1=new jana(11,"josh");
		 jana b2=new jana(22,"boss");
		 obj.put(1,b1);
		 obj.put(2,b2);
		 /*for(Map.Entry<Integer,jana> r:obj.entrySet())
		 {
		    int key=r.getKey();
		    jana b=r.getValue();
		    System.out.println(key+" "+b.id+" "+b.name);
		 }*/
		 Set s=obj.entrySet();
		 Iterator<Map.Entry<Integer,jana>> i=obj.entrySet().iterator();
		 while(i.hasNext())
		 {
			 Map.Entry<Integer,jana>j=i.next();
			 int key=j.getKey();
			 jana f=j.getValue();
			 //jana q=(jana)j;
		 
			 System.out.println(key+" "+f.id+" "+f.name);
		 }
		}
		

	}


