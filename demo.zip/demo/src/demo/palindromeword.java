package demo;

public class palindromeword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str= "ata ata jana ii";
		String s1="";
		String[] s2=str.split(" ");
		int c=0;
		for(String s3:s2)
		{
			String s4="";
			for(int i=s3.length()-1;i>=0;i--)
			{
				s4=s4+s3.charAt(i);
			
			if(s4.equals(s3))
			{
				s1=s1+s4;
				c++;
				}
			}
			
		
		s1=s1+" ";
		}
		System.out.println(s1);
		System.out.println(c);
	}

}
