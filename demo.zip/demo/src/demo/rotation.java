package demo;

import java.util.Arrays;

public class rotation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,3,4,5};
		int n=3;
		int size=arr.length;
		for(int j=1;j<=n;j++)
		{
			int last=arr[size-1];
			for(int i=size-1;i>0;i--)
			{
				arr[i]=arr[i-1];
			}
			arr[0]=last;
		}
		System.out.println(Arrays.toString(arr));

	}

}
