package demo;
import java.util.*;
import java.util.Arrays;

public class previousalbhet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan is good ";
		String s1="";
		String[]s2=str.split(" ");
		for(String s3:s2)
		{
			char ch=s3.charAt(0);
			int x=Character.hashCode(ch)+1;
			char z=(char)x;
			String s4=s3.substring(1);
			s1=s1+z+s4+" ";
		}
		System.out.println(s1);
}
}