package demo;
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class input {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		FileInputStream obj=new FileInputStream("/home/miracle/Desktop:\\ball");
		BufferedInputStream objj=new BufferedInputStream(obj);
		int i=1;
		while((i=objj.read())!=-1)
{
		System.out.print((char)i);
}
		objj.close();
		obj.close();
		
		
	
	}

}
