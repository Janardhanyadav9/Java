package demo;

public class stri {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="this is boys and anot girl";
		String s1="";
		String[]str=s.split(" ");
		int c=1;
		for(String s2:str)
		{
			int k=1;
			for(int j=0;j<=s2.length();j++)
			{
				if(str[j].equals(s2))
				{
					k++;
				}
			}
			if(k>c)
			{
				c=k;
				s1=s2;
				//System.out.println(s1);
			}
			//System.out.println(k);
		}
		System.out.println(s1);
		
//		for(String h:str)
//		{
//			if(s1.length()==h.length())
//			{
//				System.out.println(h+" ");
//			}
			
		}

	}


