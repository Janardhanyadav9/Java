package demo;

public class revchar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan is good";
		String s1="";
		String[]s2=str.split(" ");
		for(String s3:s2)
		{
			for(int i=s3.length()-1;i>=0;i--)
			{
				char ch=s3.charAt(i);
				s1=s1+ch;
			}
			s1=s1+" ";
		}
		System.out.println(s1);

	}

}
