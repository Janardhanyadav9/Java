package demo;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileOutputStream;

import java.io.IOException;

public class outputstream {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		
		
		FileOutputStream file=new FileOutputStream("/home/miracle/Desktop:\\ball");
		BufferedOutputStream files=new BufferedOutputStream(file);
		String s="jana";
		byte[]b=s.getBytes();
		//file.write(b);
		files.write(b);
		//files.flush();
		files.close();
		file.close();
		
		FileInputStream obj=new FileInputStream("/home/miracle/Desktop:\\ball");
		BufferedInputStream objj=new BufferedInputStream(obj);
		int i=1;
		while((i=objj.read())!=-1)
{
		System.out.print((char)i);
}
		objj.close();
		obj.close();
		
		
	
	}


		
		

	}


