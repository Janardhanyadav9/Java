package demo;
import java.io.*;
import java.util.*;
public class chaa {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		int c=0;int v=0;int d=0;
		File file=new File("/home/miracle/Desktop:\\ball");
		Scanner sc=new Scanner(file);
		while(sc.hasNextLine())
		{
			String s=sc.nextLine();
			for(int i=0;i<s.length();i++)
			{
				if(s.charAt(i)=='a'|| s.charAt(i)=='e'||s.charAt(i)=='i'||s.charAt(i)=='o'||s.charAt(i)=='u')
				{
					c++;
				}
				else if(s.charAt(i)>=65 && s.charAt(i)<=90  || s.charAt(i)>=97 && s.charAt(i)<=122)
				{
					v++;
				}
				else if(s.charAt(i)>=48 && s.charAt(i)<=57)
				{
					d++;
				}
				else
				{
					System.out.println("special");
				}
			
		}
			
	}
		System.out.println(c);
		System.out.println(d+" "+v);
	}
}
	


