package demo;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

public class cs {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileInputStream obj=new FileInputStream("/home/miracle/Desktop:\\ball");
		int i=0;
		while((i=obj.read())!=-1)
		{
		System.out.print((char)i);
		}
		obj.close();

	}

}
