package demo;
import java.util.*;

public class treemap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer,String>obj=new TreeMap<Integer,String>();
		obj.put(1,"jana");
		obj.put(2,"janu");
		obj.put(3,"jaquar");
		//obj.remove(2);
		Set s=obj.entrySet();
		Iterator i=s.iterator();
		//while(i.hasNext())
		//{
		//	Map.Entry k=(Map.Entry)i.next();
			//System.out.println(k.getKey()+" "+k.getValue());
		//}
		//obj.remove(2);
		while(i.hasNext())
		{
			Map.Entry k=(Map.Entry)i.next();
			System.out.println(k.getKey()+" "+k.getValue());
		}
		

	}

}
