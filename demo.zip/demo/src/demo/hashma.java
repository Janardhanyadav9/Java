package demo;
import java.util.*;

public class hashma {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList<Integer>h=new ArrayList<Integer>();
		for(int i=0;i<=6;i++)
		{
			h.add(i);
			
			int Index =h.get(i);
			System.out.println("element:"+i+" "+"element stored:"+Index);
		}

	}

}
