package demo;

public class reverstr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan yadav";
		String s="";
		String[] s1=str.split(" ");
		for(String s2:s1)
		{
			for(int i=s2.length()-1;i>=0;i--)
			{
				s=s+s2.charAt(i);
			}
			s=s+" ";
		}
		System.out.println(s);
		
}
}
