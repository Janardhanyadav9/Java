package demo;

 interface A {
	 void add();
 }
 interface B{
	 void add();
 }
 class C implements A,B
 {
	 public void add(int a,int b)
	 {
		 System.out.println(a+b);
	 }
	 public void add()
	 {
		 System.out.println(5+9);
	 }
	 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		C obj=new C();
		obj.add(2,3);
		obj.add();
		

	}

}
