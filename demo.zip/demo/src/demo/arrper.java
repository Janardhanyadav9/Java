package demo;

public class arrper {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {1,2,3,5,6,7};
		int sum=0;int c=0;
for(int i=0;i<=arr.length-1;i++)
{
	sum=0;
	for(int j=1;j<arr[i];j++)
	{
	if(arr[i]%j==0)
	{
		sum=sum+j;
	}
}
	if(sum==arr[i])
	{
		c++;
		System.out.println(arr[i]);
	}
		
}

	}

}
