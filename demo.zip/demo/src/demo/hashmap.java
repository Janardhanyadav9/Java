package demo;

import java.util.*;
public class hashmap {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashMap<Integer,String>h=new HashMap<Integer,String>();
		h.put(1,"jana");
		h.put(2,"janu");
		h.put(3,"jaquar");
		h.put(4,"janu");
		//Set s=h.entrySet();
		//Iterator d=s.iterator();
		//while(d.hasNext())
		//{
		//	Map.Entry m=(Map.Entry)d.next();
		//	System.out.println(m.getKey()+" "+m.getValue());
		//}
		for(Map.Entry m1:h
				.entrySet())
		{
		System.out.println(m1.getKey()+" "+m1.getValue());
		}
	}

}
