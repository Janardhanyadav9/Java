package demo;

public class cha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan yadav is tall";
		String s1="";
		String[]s2=str.split(" ");
		int k=0;
		for(String s3:s2)
		{
			if(k%2==0)
			{
				s1=s1+Character.toUpperCase(s3.charAt(0));
				s1=s1+s3.substring(1);
			}
			else
			{
				s1=s1+s3.charAt(k);
			}
			s1=s1+" ";
		}
		System.out.println(s1);

	}

}
