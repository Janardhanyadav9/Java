package demo;
import java.util.*;
public class book {
	int id;
	String name,author,publisher;
	int quantity;
	
 /*public book(int i, String string, String string2, String string3, int j) {*/
		// TODO Auto-generated constructor stub
	
public book(int id,String name,String author,String publisher,int quantity)
{
	this.id=id;
	this.name=name;
	this.author=author;
	this.publisher=publisher;
	this.quantity=quantity;

	
}


	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet obj=new HashSet();
		book b1=new book(1,"life","jana","miracle",8);
		book b2=new book(2,"died","janu","iracle",7);
		book b3=new book(3,"living","jaquar","racle",6);
		
		obj.add(b1);
		obj.add(b2);
		obj.add(b3);
		Iterator i=obj.iterator();
		while(i.hasNext())
		{
			book c=(book)i.next();
			System.out.println(c.id+" "+c.name+" ");
		}
		//for(book b:obj)
		//{
		//	System.out.println(b.id+" "+b.name+" "+b.author+" "+b.publisher+" "+b.quantity);
		//}
		
		

	
	}

}