package stream;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.PrintWriter;

public class printwr {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		PrintWriter p=new PrintWriter(System.out);
		p.write("hello");
		p.close();
		
		PrintWriter b=new PrintWriter("/home/miracle/Desktop:\\ball");
		b.write("hello bye");
		b.close();

	}

}
