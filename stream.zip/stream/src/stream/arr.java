package stream;
import java.io.*;
import java.util.*;
import java.util.ArrayList;
class emp implements Serializable
{
	int id;
		String name;
		emp(int id,String name)
		{
			this.id=id;
			this.name=name;
		}
}

public class arr {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		emp obj=new emp(1,"jana");
		emp obj1=new emp(2,"ramu");
		try 
		{
		ArrayList<emp> h=new ArrayList<emp>();
		h.add(obj);
		h.add(obj1);
		FileOutputStream s=new FileOutputStream("/home/miracle/Desktop:\\ban");
		ObjectOutputStream b=new ObjectOutputStream(s);
		/*for(Object i:h)
		{
			emp c=(emp)i;
		
		//b.writeObject(obj);
		b.writeObject(c);
		}*/
		b.writeObject(h);
		
	FileInputStream a=new FileInputStream("/home/miracle/Desktop:\\ban");
		ObjectInputStream k=new ObjectInputStream(a);
//		for(emp j:h)
//		{
//			System.out.println(j.id+" "+j.name);
//		}
		//while(k!=null)//it also possible. 
//		int i;
//			while((i=k.read())!=1) {
//				emp d=(emp)k.readObject();
//				System.out.println(d.id+" "+d.name);
//			}
		ArrayList m=(ArrayList) k.readObject();
		for(int i=0;i<m.size();i++)
		{
			emp o=(emp)m.get(i);
		
		System.out.println(o.id+" "+o.name);
		}
			}
		catch(Exception e)
		{
			e.getMessage();  
		}

	}

}
