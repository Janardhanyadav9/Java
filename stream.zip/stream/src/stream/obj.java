package stream;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;

class emp implements Serializable
{
	int id;
	String name;
	emp(int id,String name)
	{
		this.id=id;
		this.name=name;
	}
}

public class obj {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		emp obj=new emp(1,"jana");
		emp obj1=new emp(2,"yadav");
		ArrayList<emp>h=new ArrayList<emp>();
		h.add(obj);
		h.add(obj1);
		try
		{
		FileOutputStream s=new FileOutputStream("/home/miracle/Desktop:\\ban");
		ObjectOutputStream b=new ObjectOutputStream(s);
		//b.writeObject(obj);
		b.writeObject(h);
			b.close();
			s.close();
			
//			FileInputStream a=new FileInputStream("/home/miracle/Desktop:\\ban");
//			ObjectInputStream k=new ObjectInputStream(a);
			for(Object j:h)
			{
				emp e=(emp)j;
				System.out.println(e.id+" "+e.name);			
				}
//			for(emp g:h)
//			{
//				System.out.println(g.id+" "+g.name);
//			}
//			int i;
//			while((i=k.read())!=1)
//		{
//				emp e=(emp)k.readObject();
//				System.out.println(e.id+" "+e.name);
//			}

	}
		catch(Exception e)
		{
			e.getMessage();
		}

}
}
