import java.io.File;
import java.util.Scanner;

public class dtyu {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int c=0;int l=4;
		File file=new File("/home/miracle/Desktop:\\ball");
		Scanner sc=new Scanner(file);
		while(sc.hasNextLine())
		{
			c++;
			if(c==l)
			{
				String a=sc.nextLine();
				System.out.println(a);
			}
			sc.nextLine();
			
		}

	}

}
