function myfuntion()
{
    let x=document.getElementById("jana");
    document.getElementById("hi").innerHTML="hello";
}