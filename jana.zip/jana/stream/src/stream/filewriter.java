package stream;

import java.io.FileWriter;
import java.io.IOException;

public class filewriter {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileWriter b=new FileWriter("/home/miracle/Desktop:\\ball");
		b.write("janardhan yadav");
		b.close();

	}

}
