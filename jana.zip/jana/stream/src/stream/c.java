package stream;

import java.io.*;
import java.util.Scanner;

public class c {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		int c=0;int l=4;
		File file=new File("/home/miracle/Desktop:\\ball");
		Scanner sc=new Scanner(file);
		while(sc.hasNextLine())
		{
			c++;
			if(c==l)
			{
				String a=sc.nextLine();
				System.out.println(a);
			}
			sc.nextLine();
			
		}

	}

}
