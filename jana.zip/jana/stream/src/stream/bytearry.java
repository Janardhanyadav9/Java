package stream;
import java.io.*;
import java.util.Scanner;

public class bytearry {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		FileOutputStream s=new FileOutputStream("/home/miracle/Desktop:\\ball");
		FileOutputStream s1=new FileOutputStream("/home/miracle/Desktop:\\bat");
		ByteArrayOutputStream b=new ByteArrayOutputStream();    
		String a="janardhan";
		byte[]d=a.getBytes();
		b.write(d);
		b.writeTo(s);
		b.writeTo(s1);
		s.close();
		s1.close();
		
		FileInputStream obj=new FileInputStream("/home/miracle/Desktop:\\ball");
		FileInputStream objj=new FileInputStream("/home/miracle/Desktop:\\bat");
		//byte[]z=obj.readAllBytes();
		//ByteArrayInputStream p=new ByteArrayInputStream(z); 
	int i;
	while((i=obj.read())!=-1)
	{
			System.out.print((char)i);
	}
		

	}

}
