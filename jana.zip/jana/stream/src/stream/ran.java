package stream;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;

class run implements Serializable{
	int id;
	//transient String name;
	String name;

 run(int id,String name)
{
	this.id=id;
	this.name=name;
}
}

public class ran {

	public static void main(String[] args) throws IOException, ClassNotFoundException {
		// TODO Auto-generated method stub
		run o=new run(1,"jana");
		 run o1=new run(2,"raju");
		 
	try
	{
	FileOutputStream s=new FileOutputStream("/home/miracle/Desktop:\\ban");
	ObjectOutputStream b=new ObjectOutputStream(s);
	b.writeObject(o);
	b.writeObject(o1);
		b.close();
		s.close();
		

			
	
	FileInputStream a=new FileInputStream("/home/miracle/Desktop:\\ban");
	ObjectInputStream k=new ObjectInputStream(a);
	//Scanner p=new Scanner(bb);
		/*int i;
		while((i=k.read())!=1) {
			run d=(run)k.readObject();
			System.out.println(d.id+" "+d.name);
		}*/
	while(k!=null)
	{
		run z=(run)k.readObject();
		System.out.println(z.id+" "+z.name);
	}
	}
	catch(Exception e)
	{
		e.getMessage();
	}

	

	}

}
