package stream;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

public class append {

	public static void main(String[] args) throws IOException {
		// TODO Auto-generated method stub
		File file=new File("/home/miracle/Desktop:\\ball");
		FileWriter s=new FileWriter(file,true);
		BufferedWriter buffer=new BufferedWriter(s);
		s.append("this is append");
		buffer.close();
		System.out.println("successfull");

	}

}
