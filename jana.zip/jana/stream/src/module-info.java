/**
 * 
 */
/**
 * @author miracle
 *
 */
module stream {
}