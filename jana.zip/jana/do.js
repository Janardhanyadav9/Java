    function add()
    {
        var a=10;
        var b=20;
        var c=a+b;
        console.log(c);
        document.getElementById("hi").innerHTML=c;
    }
