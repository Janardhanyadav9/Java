package sample;

public class arr {
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int arr[]= {2,6,7,8,9,4};
		int max=arr[0];
		int min=arr[0];
		int sum=0;
		int c=0;
		for(int i=0;i<=arr.length-1;i++)
		{
			sum=sum+arr[i];
			c++;
			if(arr[i]>max)
			{
				max=arr[i];
			}
			if(arr[i]<min)
			{
				min=arr[i];
			}
		}
			System.out.println(min+" "+max+" "+sum/c);
		
		

	}

}
