package sample;

public class mulitplication {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int i=1;
		int num=2;
		do
		{
			
				System.out.println(num+"*"+i+"="+num*i);
			
		i++;
		}
		while(i<=10);
	}

}
