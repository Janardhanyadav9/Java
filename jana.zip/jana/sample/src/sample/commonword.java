package sample;
import java.util.*;
public class commonword {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a string");
		String a=sc.nextLine();
		System.out.println("enter a string");
		String b=sc.nextLine();
		String[] w1=a.split(" ");
		String[] w2=b.split(" ");
		String w="";
		for(int i=0;i<w1.length;i++)
		{
			for(int j=0;j<w2.length;j++)
			{
				if(w1[i].equals(w2[j]))
				{
					w=w+w1[i];
				}
			}
		}
		System.out.println(w);

	}

}
