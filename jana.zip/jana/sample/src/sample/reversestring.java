package sample;

public class reversestring {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan is good";
		String rev="";
		for(int i=str.length()-1;i>0;i--)
		{
			rev=rev+str.charAt(i);
			rev=rev+"";
		}
		System.out.println(rev);

	}

}
