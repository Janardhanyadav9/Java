package sample;

public class fabnonic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=0;int b=1;
		System.out.print(a+" "+b+" ");
		for(int k=1;k<5;k++)
		{
			//System.out.println(a+""+b+"");
			int c=a+b;
			//System.out.println(a);
			a=b;
			b=c;
		
		System.out.print(c+" ");
		}
	}

}
