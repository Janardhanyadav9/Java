package sample;
import java.util.*;

public class Stringbasic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="jana";
		String b="rdhan";
		//String str=new String("jana");
		String a=s.concat(b);
		System.out.println(a);

	}

}
