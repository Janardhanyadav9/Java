package sample;

public class mutilple {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*int sum=0;
		for(int i=1;i<=20;i++)
		{
			if(i%2==0)
			{
				sum+=i;
			/*System.out.println(5+"*"+i+"="+5*i);*/
			/*System.out.println(i+"*"+i+"="+i*i);*/
		/*System.out.println(sum);*/
		int n=20;
		int i=1;
		while(i<=n)
		{
			if(i%2==0)
			{
				System.out.println(i);
			}
			i++;
		}
			
			
		

	}

}
