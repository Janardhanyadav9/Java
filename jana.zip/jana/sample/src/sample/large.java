package sample;

public class large {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=100;
		int b=45;
		int c=55;
		if(a>=b && a>=c)
		{
			System.out.println(a+" is a big number");
		}
		else if(b>=c)
		{
			System.out.println(b+" is a big number");
		}
		else
		{
			System.out.println(c+" is a big number");
		}

	}

}
