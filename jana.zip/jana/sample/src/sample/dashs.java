package sample;

abstract class da
{
    void fans()
    {
        System.out.println("jana");
    }
    abstract void fun();
    abstract void sum();
}

class dashs extends da
{
	void fun()
	{
	System.out.println("jaquar");
	}
	void sum()
	{
		System.out.println("add of number");
	}





public static void main(String[] args) {
		// TODO Auto-generated method stub
		da o=new dashs();
		
		o.fans();
		o.fun();
		o.sum();

	}
}


