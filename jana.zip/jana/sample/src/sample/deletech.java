package sample;
import java.util.*;

public class deletech {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="jana";
		int d=0;
		for(int i=0;i<4;i++)
		{
			d++;
			char c=s.charAt(i);
		
		System.out.print(c);
		}
		System.out.println(d);
		
	}

}
