package sample;
import java.util.Scanner;

public class character {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter the character");
		char YourFirstIntial=sc.next().charAt(0);
		System.out.println("this is your Intial"+" "+YourFirstIntial);

	}

}
