package sample;

interface A
{
	void fun();
	void fan();
	}

 class robo implements A 
 {
	 public void fun()
	 {
		 System.out.println("joke");
	 }
	 public void fan()
	 {
		 System.out.println("jokes");
	 }

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		robo obj=new robo();
		obj.fun();
		obj.fan();

	}

}
