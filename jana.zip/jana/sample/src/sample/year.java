package sample;

public class year {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=2020;
		if(((a%4==0) && (a%100!=0))||(a%400==0))
		{
			System.out.println("leap year");
		}
		else
		{
			System.out.println("not a leap year");
		}

	}

}
