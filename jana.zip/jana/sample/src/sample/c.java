package sample;

public class c {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="janardhan is tall";
		String s1="";
		String[]s2=s.split(" ");

		
			for(int i=0;i<s2.length;i++)
			{
				if(i%2==0)
				{
					for(int j=0;j<s2[i].length();j++)
					{
				if(s2[i].charAt(j)=='a'|| s2[i].charAt(j)=='e'||s2[i].charAt(j)=='i'||s2[i].charAt(j)=='o'||s2[i].charAt(j)=='u' &&s2[i].charAt(j)==' ')
				{
					s1=s1+s2[i].charAt(j);
				}
					//System.out.println(s2[i].charAt(j));
				}
					s1=s1+" ";
				}
				else {
					for(int j=0;j<s2[i].length();j++)
					{
				if(s2[i].charAt(j)!='a'&& s2[i].charAt(j)!='e'&&s2[i].charAt(j)!='i'&&s2[i].charAt(j)!='o'&&s2[i].charAt(j)!='u')
				{
					s1=s1+s2[i].charAt(j);
				}
					
					//System.out.println(s3.charAt(0));
				}
				s1=s1+" ";
			
				}
				}
			System.out.println(s1);
	}
	}

	
	
		
	

