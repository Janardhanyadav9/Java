package sample;

public class expection1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try {
			int arr[]= {1,2,3,4,5};
			int ar[]=new int[arr.length];
			for(int i=0;i<arr.length;i++)
			{
				 ar[i]=arr[i];
			
			System.out.println(ar[i]);
			}
			System.out.println(arr[10]);
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
		System.out.println(e);	
		
		}
		System.out.println("handle");

	}

}
