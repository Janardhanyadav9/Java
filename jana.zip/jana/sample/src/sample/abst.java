package sample;
abstract class a
{
abstract void add(int a,int b);
abstract void add(int a,int b,int c);
void run(int a,int b)
{
	System.out.println(a+b);
}
}
public class abst extends a
{
	void add(int a,int b)
	{
	System.out.println(a+b);
}

	void add(int a,int b,int c)
	{
	System.out.println(a+b+c);
}
	void run(int a,int b,int c)
	{
	System.out.println(a+b+c);
}
	
	




	public static void main(String[] args) {
		// TODO Auto-generated method stub
abst h=new abst();
h.add(2,3);
h.add(2,4,8);
//h.add(4, 3);
h.run(5,9);
h.run(5,8,9);

	}

}
