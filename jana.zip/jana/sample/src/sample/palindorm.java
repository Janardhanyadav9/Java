package sample;

public class palindorm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r=0;
		int rev=0;
		int n=121;
		int temp=n;
		while(n!=0)
		{
			r=n%10;
			rev=r+(rev*10);
			n=n/10;
		}
		if(temp==rev)
		{
		System.out.println(rev);
		}
		else
		{
			System.out.println("not palin");
		}
		

	}

}
