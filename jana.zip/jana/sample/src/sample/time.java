package sample;
import java.util.Scanner;

public class time {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int hours=sc.nextInt();
		int sec=3600*hours;
		System.out.println(sec);

	}

}
