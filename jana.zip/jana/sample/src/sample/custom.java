package sample;


class janaException extends Exception
{
	janaException(String s)
	{
		super(s);
	}
}


public class custom 
{
	public static void main(String[] args)throws janaException {
		// TODO Auto-generated method stub
try
{
	int n=3;
	if(n>0)
	{
		int a=10;
		int b=0;
		int c=a/b;
		System.out.println("hello");
	}
	else
	{
		throw new janaException("insufficient");
	}
}
	catch(Exception e)
	{
		System.out.println(e);
	}
		
	}
}
	


