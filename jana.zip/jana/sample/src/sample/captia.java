package sample;

public class captia {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="janardhan yadav";
		String str="";
		//String str2="";
		
		str=str+Character.toUpperCase(s.charAt(0));
		for(int i=1;i<s.length();i++)
		{
			
		
			
			if(s.charAt(i)==' ')
			{
				 char st=Character.toUpperCase(s.charAt(i+1));
				 str=str+" "+st;
				 i++;
			
				 continue;
			}
			
			str=str+s.charAt(i);
		}
			System.out.println(str);

}
	}
