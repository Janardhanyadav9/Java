package sample;

public class alternativ {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan is tall";
		String s="";
		String[] s1=str.split(" ");
		for(int i=0;i<s1.length;i++)
		{
			if(i%2==0)
			{
				s=s+s1[i].toUpperCase();
			}
			else
			{
			 s=s+s1[i].toLowerCase();
			}
			s=s+" ";
		}
		System.out.println(s);
		
		
		

	}

}
