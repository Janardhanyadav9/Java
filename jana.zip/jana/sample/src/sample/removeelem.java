package sample;

public class removeelem {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="jana rdh an";
		String s=str.toUpperCase();
		System.out.println("removing a element in a string"+" "+str.replace("a",""));
		System.out.println("removing a space in a string"+" "+str.replace("",""));
		System.out.println("removing a elements in a string"+" "+str.replace("an",""));
		System.out.println("changing a element into upper string"+" "+str.replace(("[A-Z]"),""));
		System.out.println("cahging  a element in a sub string"+" "+str.substring(0,str.length()-1));
		System.out.println("removing a element in a string"+" "+s);
		
		

	}

}
