package sample;
import java.util.*;

public class occuren {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		System.out.println("enter a number");
		int n=sc.nextInt();
		int arr[]=new int[10];
		while(n!=0)
		{
			int d=n%10;
			arr[d]++;
			n=n/10;
		}
		System.out.println("occurence of digit");
		for(int i=0;i<10;i++)
		{
			if(arr[i]>0)
			{
				System.out.println(i+" "+arr[i]);
			}
		}
		

	}

}
