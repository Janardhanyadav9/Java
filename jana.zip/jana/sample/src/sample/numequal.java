package sample;

public class numequal {
	static String checknumber(int n)
	{
		int ldigit=n%10;
		while(n!=0)
		{
			int digit=n%10;
			if(ldigit!=digit)
			{
				return "no";
			}
			n=n/10;
		}
			return "yes";
		
		
		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=131;
		System.out.println(checknumber(n));


	}

}
