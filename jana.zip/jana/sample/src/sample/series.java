package sample;

public class series {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		double sum=1;
		for(int i=1;i<=5;i++)
		{
			//sum=sum+1/(double)i;
			//sum=sum+1/(double)Math.pow(2,sum);
			sum=sum+1/(double)(Math.pow(2,i));
		}
		System.out.println(sum);

	}

}
