package sample;
import java.util.Scanner;
public class arr1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int []arr=new int[10];
		Scanner sc=new Scanner(System.in);
		for(int i=0;i<5;i++)
		{
			int n=sc.nextInt();
			arr[i]=n;
		}
		int temp;
		for(int i=0;i<5-1;i++)
		{
			for(int j=0;j<5-1;j++)
			{
				if(arr[j]>arr[j+1])
				{
					temp=arr[j];
					arr[j]=arr[j+1];
					arr[j+1]=temp;
				}
			}
		}
		for(int i=0;i<5;i++)
		{
			System.out.print(arr[i]+" ");
		}

	}

}
