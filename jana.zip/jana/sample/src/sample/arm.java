package sample;

public class arm {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int r=0;
		double sum=0;
		int n=153;
		int temp=n;
		while(n!=0)
		{
			r=n%10;
			sum=sum+(double)(Math.pow(r,3));
			n=n/10;
		}
		if(temp==sum)
		{
			System.out.println("arm");
		}
		else
		{
			System.out.println("not arm");
		}

	}

}
