package sample;

public class alphabetic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan";
		char a[]=str.toCharArray();
		for(int i=0;i<a.length;i++)
		{
			for(int j=i+1;j<a.length;j++)
			{
				if(a[i]<a[j])
				{
				char temp=a[i];
				a[i]=a[j];
				a[j]=temp;
			}
			}
		
		
		System.out.println(a[i]);
	}}
	}


