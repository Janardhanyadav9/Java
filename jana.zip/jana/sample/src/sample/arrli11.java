package sample;
import java.util.*;

public class arrli11 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList arr=new ArrayList();
		System.out.println(arr);
		ArrayList arr1=new ArrayList();
		arr1.add("jana");
		arr1.add("janu");
		System.out.println(arr1);
		System.out.println(arr1.retainAll(arr1));

	}

}
