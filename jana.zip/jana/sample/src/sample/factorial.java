package sample;

public class factorial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=1;
		for(int i=1;i<=5;i++)
		{
			a=a*i;
		}
			System.out.println(a);
		

	}

}
