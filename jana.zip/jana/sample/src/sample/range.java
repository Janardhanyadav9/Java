package sample;
import java.util.Scanner;
public class range {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		int b=sc.nextInt();
		if(a<b)
		{
			System.out.println("In Range");
		}
		else
		{
			System.out.println("not in range");
		}

	}

}
