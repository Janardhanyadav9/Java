package sample;

public class asic {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("enter a charater");
		char c='@';
		int m=c;
        if(m >= 97 && m <= 123)

        {

            System.out.println("Lower Case");

        }

        else if(m >= 65 && m <= 96)

        {

            System.out.println("Upper Case");

        }

        else if(m >= 48 && m <= 57)

        {

            System.out.println("Digit");

        }
        else
        {
        	System.out.println("special character");

    }
	}

}
