package sample;
import java.util.Scanner;

public class digits {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		int c=0;
		int n=3;
		int sum=0;
		while(n!=c)
		{
			int a=sc.nextInt();
			sum=sum+a;
			c++;
		
		}	
System.out.println(sum/c);
	}

}

