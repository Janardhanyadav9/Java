package sample;

public class d {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int n=20;
		int i=1;
		do {
			if(i%2==0)
			{
				System.out.println(i);
			}
			i++;
		}
		while(i<=n);
		
		
	}

}
