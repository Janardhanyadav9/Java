package sample;
import java.util.*;

public class eliminatespecial {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc=new Scanner(System.in);
		String s="";
		System.out.println("enter a string");
		String a=sc.nextLine();
		for(int i=0;i<a.length();i++)
		{
			if((a.charAt(i)>=65 && a.charAt(i)<=90) || (a.charAt(i)>=97 && a.charAt(i)<=122))
			{
			s=s+a.charAt(i);	
			}
		}
		System.out.println(s);
		
		

	}

}
