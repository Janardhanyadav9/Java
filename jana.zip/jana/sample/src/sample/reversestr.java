package sample;

public class reversestr {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan yadav";
		String s="";
		String[] s1=str.split(" ");
		for(String s3:s1)
		{
			for(int i=s3.length()-1;i>=0;i--)
			{
				s=s+s3.charAt(i);
				
			}
			s=s+" ";
		}
		System.out.println(s);
		
	}

}
