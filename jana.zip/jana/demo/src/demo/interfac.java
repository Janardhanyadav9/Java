package demo;
interface done
{
	void sub();
	void add();
}
 class b implements done 
 {
 public void sub()
 {
	 System.out.println("this is sub");
 }
 public void add()
 {
	 System.out.println("this is add");
 }
 }
class interfac extends b
{
	public void add()
	{
		System.out.println("this is multiply");
	}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		interfac obj=new interfac();
		obj.add();
		obj.sub();
		obj.add();

	}

}
