package demo;

public class alterprime {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int sum=0;
		int c=0;
		int k=0;
		for(int i=1;i<=20;i++)
		{
			c=0;
			for(int j=1;j<20;j++)
			{
				if(i%j==0)
				{
					c++;
				}
			}
			if(c==2)
			{
				if(k%2==0)
				{
					System.out.println(i);
				}
				k++;
			}
		
		
		}
	}

}
