package demo;

public class word {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="janardhan is tall";
		String s1="";
		int c=1;
		for(int i=0;i<s.length()-1;i++)
		{
			if((s.charAt(i)==' ') && (s.charAt(i+1)!=' '))
			{
				c++;
			}
	}
		System.out.println(c);

	}
}
