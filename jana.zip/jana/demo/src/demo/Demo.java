package demo;

import java.util.*;
public class Demo {
	int id;
	String name;
	
public Demo(int id,String name)
{
	this.id=id;
	this.name=name;
}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		TreeMap<Integer,Demo>h=new TreeMap<Integer,Demo>();
		Demo d1=new Demo(11,"jana");
		Demo d2=new Demo(21,"jaquar");
		h.put(1,d1);
		h.put(2,d2);
		for(Map.Entry<Integer,Demo> r:h.entrySet())
		{
		int key=r.getKey();
		Demo b=r.getValue();
		//System.out.println(key+"details");
		System.out.println(key+" "+b.id+" "+b.name);

	}

}
}
