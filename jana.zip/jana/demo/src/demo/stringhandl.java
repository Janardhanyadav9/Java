package demo;

public class stringhandl {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		try
		{
		int a=50;
		int b=0;
		int arr[]= {1,2,3,4,5};
		for(int i=0;i<arr.length;i++)
		{
			arr[i+1]=arr[i];
		}
		int c=a/b;
		String s="";
		}
		catch(ArithmeticException e)
		{
			e.printStackTrace();
		}
		catch(ArrayIndexOutOfBoundsException e)
		{
			e.printStackTrace();
		System.out.println(e);
		}
		finally
		{
			System.out.println("hello");
		}
	}

}
