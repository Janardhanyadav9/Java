package demo;
import java.util.*;

public class hashset1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		HashSet h=new HashSet();
		h.add("jana");
		h.add("bmw");
		h.add("bitcoin");
		h.add("jana");
		Iterator i=h.iterator();
		while(i.hasNext())
		{
			System.out.println(i.next());
		}

	}

}
