package demo;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class map {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="janardhan";
		ArrayList<Character>arr=new ArrayList<Character>();
		HashMap<Character,Integer>h=new HashMap<Character,Integer>();
		for(int i=0;i<s.length();i++)
		{
			arr.add(s.charAt(i));
		}
		for(int i=0;i<arr.size();i++)
		{
			h.put(arr.get(i),0);
		}
		for(int i=0;i<arr.size();i++)
		{
			h.put(arr.get(i),h.get(arr.get(i))+1);
		}
		for(Map.Entry m:h.entrySet())
		{
			System.out.println(m.getKey()+" "+m.getValue());
		}
		

	}

}
