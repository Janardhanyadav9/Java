package demo;
import java.util.*;
import java.io.*;

public class inter {

	public static void main(String[] args) throws FileNotFoundException {
		// TODO Auto-generated method stub
		int c=0;
		File file=new File("/home/miracle/Desktop:\\ball");
		String s="jana";
		Scanner sc=new Scanner(file);
		while(sc.hasNextLine())
		{
			String a=sc.nextLine();
			if(a.equals(s))
			{
				System.out.println(a);
				break;
			}
			c++;
		}
		System.out.println("number of count :"+c);
		sc.close();

	}

}
