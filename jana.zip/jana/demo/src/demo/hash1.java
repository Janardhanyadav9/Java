package demo;

import java.util.*;
public class hash1 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		ArrayList h=new ArrayList();
		h.add(1);
		h.add(2);
		h.add(2);
		h.add(2);
		Iterator i=h.iterator();
		while(i.hasNext())
		{
		System.out.println(i.next());	
		}
		

	}

}
