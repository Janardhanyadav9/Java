package demo;

public class alternativecha {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan";
		String s="";
		for(int i=0;i<=str.length()-1;i++)
		{
			char ch=str.charAt(i);
			
			if(i%2==0)
			{
				s=s+Character.toUpperCase(str.charAt(i));
			}
			else
			{
				s=s+str.charAt(i);
			}
		}
		System.out.println(s);

	}

}
