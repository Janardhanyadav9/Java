package demo;

public class str {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="janardhan used a laptop";
		String[]s1=s.split(" ");
		int x=0;
		for(String s2:s1)
		{
			int l=s2.length();
			if(l>x)
			{
			x=l;
			//System.out.println(x);
			}
	}
		System.out.println(x);
		for(String s4:s1)
		{
			if(s4.length()==x)
			{
				System.out.println(s4+" "+x);
			}
		}
		//System.out.println(s4+" "+x);

}
}
