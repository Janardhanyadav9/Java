package demo;
abstract class a
{
	abstract void add() ;
	//abstract void add(int a,int b);
	//System.out.println("this is add");
}
	 
class honda extends a{

	@Override
	void add() {
		// TODO Auto-generated method stub
		System.out.println(2+3);		
	}
class hero extends honda
{
	void add()
	{
		System.out.println(3+9);
	}
}
	//@Override
	//void add(int a, int b) {
		// TODO Auto-generated method stub
	//	System.out.println(a+b);
	//}
	
}


public class abstrac {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		hero h=new hero();
		h.add();
		//h.add(2,7);

	}

}
