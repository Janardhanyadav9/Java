package demo;
  class demo
{
void eat()
{
	System.out.println("hello");
	}
 static void done()
{
	System.out.println("hi");
}
}
 public class over extends demo 
 {
	 void dance()
	 {
		 System.out.println("dancing");
	 }
	  static void done()
	 {
	 	System.out.println("runnning");
	 }
	 

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		demo obj=new over();
	//done();
		obj.eat();
		//obj.dance();
		obj.done();
		

	}

}
