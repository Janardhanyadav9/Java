package demo;

public class alternativechar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String str="janardhan yadav";
		String s1="";
		String[]s2=str.split(" ");
		for(String s3:s2)
		{
			for(int i=0;i<=s3.length()-1;i++)
			{
				char ch=s3.charAt(i);
				if(i%2==0)
				{
					ch=Character.toUpperCase(ch);
					s1=s1+ch;
					
				
				}
				else
				{
					s1=s1+ch;
				}
			
			}
			s1=s1+" ";
		}
				
		System.out.println(s1);
			
		
	}

}
