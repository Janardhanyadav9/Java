package demo;
public class palindorma {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String s="mam";
		String st="";
		for(int i=s.length()-1;i>=0;i--)
		{
	       st=st+s.charAt(i);
		}
	       if(st.equals(s))
	       {
			System.out.println("palin");		
			
		}
	       else
	       {
	    	   System.out.println("not palin");
	       }
		

	}

}
