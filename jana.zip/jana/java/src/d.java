 class d {
	void fan()
	{
		System.out.println("jana");
	}
 }
	class dash extends d
	{
	void fans()
	{
		System.out.println("janu");
	}
	void fan() {
		System.out.println("jai");
	}
}
	

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		dash obj=new dash();
		obj.fans();
		obj.fan();

	}


